import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "שגיא דהן | ליווי אונליין לפיתוח גוף, כוח ופאוורליפטינג",
  description:
    "ליווי אונליין בעברית לגברים שרוצים לעלות במשקל, לבנות מסת שריר, להתחזק, לשפר טכניקה ולהיכנס לעולם הפאוורליפטינג עם שגיא דהן.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="he" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
