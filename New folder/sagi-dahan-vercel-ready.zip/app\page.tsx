import Image from "next/image";
import {
  ArrowUpLeft,
  Check,
  ChevronDown,
  Dumbbell,
  Gauge,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Target,
  Trophy,
  Zap,
} from "lucide-react";

const whatsappUrl =
  "https://wa.me/972532756603?text=%D7%94%D7%99%D7%99%20%D7%A9%D7%92%D7%99%D7%90%2C%20%D7%A8%D7%90%D7%99%D7%AA%D7%99%20%D7%90%D7%AA%20%D7%94%D7%90%D7%AA%D7%A8%20%D7%A9%D7%9C%D7%9A%20%D7%95%D7%90%D7%A0%D7%99%20%D7%A8%D7%95%D7%A6%D7%94%20%D7%9C%D7%91%D7%93%D7%95%D7%A7%20%D7%90%D7%9D%20%D7%94%D7%9C%D7%99%D7%95%D7%95%D7%99%20%D7%9E%D7%AA%D7%90%D7%99%D7%9D%20%D7%9C%D7%99";

const navItems = ["הסיפור", "למי זה מתאים", "מה מקבלים", "חבילות", "שאלות"];

const audience = [
  "גברים רזים שרוצים לעלות במשקל ולבנות גוף חזק יותר.",
  "מתאמנים שנתקעו בתוכנית, במשקלים או בעלייה במסת שריר.",
  "מי שרוצה לשפר טכניקה בסקוואט, בנץ׳ ודדליפט.",
  "מתאמנים שרוצים להיכנס לפאוורליפטינג בצורה מסודרת.",
];

const includes = [
  {
    icon: Target,
    title: "תוכנית אימונים אישית",
    text: "מבנה שבועי ברור לפי המטרה, הרמה, הציוד והיכולת להתאושש.",
  },
  {
    icon: Gauge,
    title: "מעקב עומסים והתקדמות",
    text: "התאמות לפי ביצועים בפועל, RPE, משקל גוף, עייפות וזמינות.",
  },
  {
    icon: ShieldCheck,
    title: "ביקורת טכניקה",
    text: "ניתוח וידאו לתרגילים המרכזיים כדי לבנות כוח בלי לנחש.",
  },
  {
    icon: Dumbbell,
    title: "תזונה לעלייה במסה",
    text: "מסגרת פשוטה לעלייה במשקל בלי להפוך את החיים לאקסל.",
  },
];

const results = [
  { value: "45kg", label: "נקודת פתיחה רזה וחלשה" },
  { value: "Powerlifting", label: "מעבר לאימוני כוח תחרותיים" },
  { value: "IL + EU", label: "תחרויות בישראל ובאירופה" },
];

const packages = [
  {
    name: "Base",
    price: "ליווי בסיסי",
    features: ["תוכנית אימונים", "עדכון שבועי", "מעקב התקדמות", "מענה בווטסאפ"],
  },
  {
    name: "Performance",
    price: "המסלול המרכזי",
    featured: true,
    features: [
      "תוכנית אימונים מלאה",
      "ביקורות טכניקה",
      "התאמות עומסים",
      "הכוונת תזונה ועלייה במשקל",
      "מענה שוטף בווטסאפ",
    ],
  },
  {
    name: "Powerlifting Prep",
    price: "הכנה לתחרות",
    features: ["תכנון פיק", "בחירת ניסיונות", "ניהול עומסים", "אסטרטגיית יום תחרות"],
  },
];

const faqs = [
  {
    q: "האם הליווי מתאים למתחילים?",
    a: "כן. אם יש לך גישה לחדר כושר ורצון לעבוד מסודר, הליווי נבנה מהרמה הנוכחית שלך.",
  },
  {
    q: "חייבים לרצות להתחרות בפאוורליפטינג?",
    a: "לא. אפשר להתמקד בעלייה במסה, כוח וטכניקה. פאוורליפטינג הוא אופציה למי שזה מושך אותו.",
  },
  {
    q: "איך מתבצע המעקב?",
    a: "דרך עדכונים שבועיים, סרטוני טכניקה, נתוני אימון ומשקל גוף. לפי זה מבצעים התאמות.",
  },
  {
    q: "כמה זמן לוקח לראות שינוי?",
    a: "ברוב המקרים מרגישים שינוי בסדר ובביצועים כבר בחודש הראשון, ותהליך פיזי משמעותי דורש עקביות של כמה חודשים.",
  },
];

function WhatsAppButton({ label = "קבע שיחת ייעוץ בווטסאפ" }: { label?: string }) {
  return (
    <a
      href={whatsappUrl}
      className="inline-flex min-h-12 items-center justify-center gap-2 rounded-md bg-sky-400 px-5 py-3 text-sm font-bold text-slate-950 shadow-[0_0_32px_rgba(56,189,248,0.35)] transition hover:bg-white focus:outline-none focus:ring-2 focus:ring-sky-200"
    >
      <MessageCircle className="h-5 w-5" />
      {label}
    </a>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-sky-300/20 bg-sky-300/10 px-3 py-1 text-xs font-bold uppercase text-sky-200">
      <Sparkles className="h-3.5 w-3.5" />
      {children}
    </div>
  );
}

function SectionShell({
  id,
  children,
  className = "",
}: {
  id?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={`mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8 ${className}`}>
      {children}
    </section>
  );
}

export default function Home() {
  return (
    <main className="relative overflow-hidden">
      <div className="brand-grid pointer-events-none absolute inset-x-0 top-0 h-[720px]" />

      <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-950/72 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          <a href="#" className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-md border border-sky-300/30 bg-white text-sm font-black text-slate-950">
              SD
            </span>
            <span className="leading-tight">
              <span className="block text-sm font-black">שגיא דהן</span>
              <span className="block text-xs text-slate-400">Online Strength Coaching</span>
            </span>
          </a>
          <nav className="hidden items-center gap-6 text-sm text-slate-300 lg:flex">
            {navItems.map((item) => (
              <a key={item} href={`#${item}`} className="transition hover:text-white">
                {item}
              </a>
            ))}
          </nav>
          <WhatsAppButton label="וואטסאפ" />
        </div>
      </header>

      <SectionShell className="relative grid min-h-[calc(100vh-72px)] items-center gap-10 pb-10 pt-14 lg:grid-cols-[1.08fr_0.92fr] lg:pt-20">
        <div>
          <SectionLabel>Sagi Dahan Brand System v1.0</SectionLabel>
          <h1 className="text-balance max-w-4xl text-4xl font-black leading-[1.04] text-white sm:text-6xl lg:text-7xl">
            תבנה גוף חזק, תעלה במשקל, ותפסיק להתאמן לפי ניחושים.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300 sm:text-xl">
            ליווי אונליין לגברים שרוצים יותר מסת שריר, יותר כוח וטכניקה נקייה בסקוואט, בנץ׳
            ודדליפט. תהליך מדויק, אישי, ובלי רעש מיותר.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <WhatsAppButton />
            <a
              href="#מה מקבלים"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-md border border-white/15 bg-white/5 px-5 py-3 text-sm font-bold text-white transition hover:border-sky-300/50 hover:bg-sky-300/10"
            >
              לראות מה כולל הליווי
              <ArrowUpLeft className="h-4 w-4" />
            </a>
          </div>
          <div className="mt-10 grid max-w-2xl grid-cols-3 gap-3">
            {results.map((item) => (
              <div key={item.value} className="rounded-md border border-white/10 bg-white/[0.04] p-4">
                <div className="text-xl font-black text-sky-200">{item.value}</div>
                <div className="mt-1 text-xs leading-5 text-slate-400">{item.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="blue-glow relative overflow-hidden rounded-lg border border-sky-200/20 bg-slate-900">
            <Image
              src="/images/hero-training-placeholder.svg"
              alt="תמונת אימון כוח של שגיא דהן - תמונת placeholder"
              width={900}
              height={1100}
              priority
              className="aspect-[4/5] w-full object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/72 to-transparent p-5">
              <p className="text-sm font-bold text-sky-200">Powerlifting / Hypertrophy / Technique</p>
              <p className="mt-1 text-2xl font-black">מערכת ליווי שמודדת ביצועים, לא מוטיבציה.</p>
            </div>
          </div>
        </div>
      </SectionShell>

      <SectionShell id="הסיפור" className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr]">
        <div>
          <SectionLabel>הסיפור שלי</SectionLabel>
          <h2 className="text-3xl font-black leading-tight sm:text-5xl">מ־45 קילו וחוסר ביטחון לבמה תחרותית.</h2>
        </div>
        <div className="rounded-lg border border-white/10 bg-white/[0.04] p-6 text-lg leading-9 text-slate-300 sm:p-8">
          <p>
            אני שגיא דהן, פאוורליפטר ומאמן אונליין. התחלתי מהמקום שהרבה מתאמנים מכירים:
            גוף רזה מדי, ביטחון נמוך, והרבה בלבול סביב אימונים ותזונה.
          </p>
          <p className="mt-5">
            עם הזמן בניתי שיטה פשוטה יותר: להתאמן לפי נתונים, לשפר טכניקה, להתקדם בסבלנות,
            ולאכול בצורה שתומכת בעלייה אמיתית. הדרך הזאת הובילה אותי לבניית מסת שריר,
            התחזקות משמעותית ותחרויות פאוורליפטינג בישראל ובאירופה.
          </p>
        </div>
      </SectionShell>

      <SectionShell id="למי זה מתאים">
        <div className="mb-8 max-w-3xl">
          <SectionLabel>למי זה מתאים</SectionLabel>
          <h2 className="text-3xl font-black sm:text-5xl">אם אתה רוצה תהליך ברור, זה המקום.</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {audience.map((item) => (
            <div key={item} className="flex gap-4 rounded-lg border border-white/10 bg-slate-950/55 p-5">
              <span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-md bg-sky-300 text-slate-950">
                <Check className="h-4 w-4" />
              </span>
              <p className="text-lg font-bold leading-7 text-white">{item}</p>
            </div>
          ))}
        </div>
      </SectionShell>

      <SectionShell id="מה מקבלים">
        <div className="mb-8 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-3xl">
            <SectionLabel>מה מקבלים בליווי</SectionLabel>
            <h2 className="text-3xl font-black sm:text-5xl">מערכת אימון מלאה סביב המטרה שלך.</h2>
          </div>
          <WhatsAppButton label="בדוק התאמה" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {includes.map(({ icon: Icon, title, text }) => (
            <article key={title} className="rounded-lg border border-white/10 bg-white/[0.04] p-6">
              <Icon className="h-8 w-8 text-sky-300" />
              <h3 className="mt-5 text-xl font-black">{title}</h3>
              <p className="mt-3 leading-7 text-slate-400">{text}</p>
            </article>
          ))}
        </div>
      </SectionShell>

      <SectionShell className="grid items-center gap-8 lg:grid-cols-2">
        <div className="overflow-hidden rounded-lg border border-white/10 bg-slate-900">
          <Image
            src="/images/platform-placeholder.svg"
            alt="תמונת placeholder לתחרות פאוורליפטינג"
            width={900}
            height={720}
            className="aspect-[5/4] w-full object-cover"
          />
        </div>
        <div>
          <SectionLabel>Powerlifting & Results</SectionLabel>
          <h2 className="text-3xl font-black leading-tight sm:text-5xl">כוח אמיתי נבנה מתוכנית, טכניקה ומעקב.</h2>
          <p className="mt-5 text-lg leading-8 text-slate-300">
            הליווי מתאים גם למי שרוצה להתחזק בלי להתחרות, וגם למי שרוצה לקחת את זה לבמה.
            הדגש הוא על ביצוע נקי, עומסים מתוכננים וקבלת החלטות לפי התקדמות אמיתית.
          </p>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            {["סקוואט", "בנץ׳ פרס", "דדליפט"].map((lift) => (
              <div key={lift} className="rounded-md border border-sky-300/20 bg-sky-300/10 p-4 text-center font-black text-sky-100">
                {lift}
              </div>
            ))}
          </div>
        </div>
      </SectionShell>

      <SectionShell>
        <div className="mb-8 max-w-3xl">
          <SectionLabel>תוצאות ועדויות</SectionLabel>
          <h2 className="text-3xl font-black sm:text-5xl">כאן ייכנסו תוצאות מתאמנים ועדויות.</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {[1, 2, 3].map((item) => (
            <article key={item} className="rounded-lg border border-white/10 bg-white/[0.04] p-5">
              <div className="mb-5 aspect-[4/3] rounded-md border border-dashed border-sky-300/30 bg-sky-300/10" />
              <p className="text-lg font-black">שם מתאמן / תוצאה</p>
              <p className="mt-2 leading-7 text-slate-400">
                Placeholder לעדות, תמונת לפני/אחרי או שיפור במשקלי עבודה.
              </p>
            </article>
          ))}
        </div>
      </SectionShell>

      <SectionShell id="חבילות">
        <div className="mb-8 max-w-3xl">
          <SectionLabel>חבילות ליווי</SectionLabel>
          <h2 className="text-3xl font-black sm:text-5xl">בחר מסלול לפי השלב שבו אתה נמצא.</h2>
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          {packages.map((plan) => (
            <article
              key={plan.name}
              className={`rounded-lg border p-6 ${
                plan.featured
                  ? "blue-glow border-sky-300/40 bg-sky-300/10"
                  : "border-white/10 bg-white/[0.04]"
              }`}
            >
              <div className="flex items-center justify-between gap-4">
                <h3 className="text-2xl font-black">{plan.name}</h3>
                {plan.featured ? <Trophy className="h-6 w-6 text-sky-200" /> : <Zap className="h-6 w-6 text-slate-400" />}
              </div>
              <p className="mt-2 font-bold text-sky-200">{plan.price}</p>
              <ul className="mt-6 space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex gap-3 text-slate-300">
                    <Check className="mt-0.5 h-5 w-5 shrink-0 text-sky-300" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-7">
                <WhatsAppButton label="שאל על המסלול" />
              </div>
            </article>
          ))}
        </div>
      </SectionShell>

      <SectionShell id="שאלות">
        <div className="mb-8 max-w-3xl">
          <SectionLabel>FAQ</SectionLabel>
          <h2 className="text-3xl font-black sm:text-5xl">שאלות נפוצות</h2>
        </div>
        <div className="grid gap-3">
          {faqs.map((faq) => (
            <details key={faq.q} className="group rounded-lg border border-white/10 bg-white/[0.04] p-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-lg font-black">
                {faq.q}
                <ChevronDown className="h-5 w-5 shrink-0 text-sky-300 transition group-open:rotate-180" />
              </summary>
              <p className="mt-4 max-w-4xl leading-8 text-slate-400">{faq.a}</p>
            </details>
          ))}
        </div>
      </SectionShell>

      <SectionShell className="pb-24">
        <div className="overflow-hidden rounded-lg border border-sky-300/20 bg-white/[0.04] p-8 text-center blue-glow sm:p-12">
          <SectionLabel>Ready</SectionLabel>
          <h2 className="mx-auto max-w-4xl text-balance text-3xl font-black leading-tight sm:text-6xl">
            רוצה להתחיל לבנות גוף חזק יותר כבר מהשבוע הקרוב?
          </h2>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-300">
            שלח הודעה קצרה בווטסאפ. נבדוק את המטרה, הרקע, האימונים הנוכחיים והאם הליווי מתאים לך.
          </p>
          <div className="mt-8">
            <WhatsAppButton label="שלח הודעה לשגיא" />
          </div>
        </div>
      </SectionShell>
    </main>
  );
}
